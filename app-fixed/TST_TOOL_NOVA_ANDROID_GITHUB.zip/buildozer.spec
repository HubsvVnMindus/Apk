[app]
title = TST-TOOL NOVA
package.name = tsttoolnova
package.domain = vn.tsttool
source.dir = .
source.include_exts = py,kv,png,jpg,json,txt,enc
version = 3.0.0
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,ACCESS_NETWORK_STATE
android.api = 35
android.minapi = 23
android.ndk = 27c
android.archs = arm64-v8a
android.accept_sdk_license = True
android.allow_backup = False
requirements = python3,kivy==2.3.1,requests,pytz,websocket-client,rich,cryptography

[buildozer]
log_level = 2
warn_on_root = 1
