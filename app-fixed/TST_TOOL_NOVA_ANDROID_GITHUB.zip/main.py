# -*- coding: utf-8 -*-
"""NOVA DARK Android shell for the existing TST-TOOL logic."""
import builtins
import os
import queue
import re
import sys
import threading
import traceback

from kivy.app import App
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.metrics import dp
from kivy.properties import StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.utils import get_color_from_hex

ANSI_RE = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
input_queue = queue.Queue()
output_queue = queue.Queue()
_original_input = builtins.input

KV = r"""
<NovaRoot>:
    orientation: "vertical"
    padding: dp(14)
    spacing: dp(10)
    canvas.before:
        Color:
            rgba: 0.025, 0.035, 0.075, 1
        Rectangle:
            pos: self.pos
            size: self.size
    BoxLayout:
        size_hint_y: None
        height: dp(54)
        orientation: "vertical"
        Label:
            text: "[b]♛ TST-TOOL  /  NOVA DARK[/b]"
            markup: True
            color: 0.66, 0.55, 1, 1
            font_size: "20sp"
            halign: "left"
            text_size: self.size
        Label:
            text: "AI COMMAND SYSTEM  •  ANDROID"
            color: 0.48, 0.58, 0.72, 1
            font_size: "10sp"
            halign: "left"
            text_size: self.size
    BoxLayout:
        size_hint_y: None
        height: dp(3)
        canvas:
            Color:
                rgba: 0.48, 0.36, 1, 1
            Rectangle:
                pos: self.pos
                size: self.size
    TextInput:
        id: terminal
        text: root.log_text
        readonly: True
        multiline: True
        font_name: "RobotoMono"
        font_size: "12sp"
        foreground_color: 0.84, 0.88, 0.96, 1
        background_color: 0.045, 0.06, 0.12, 1
        cursor_color: 0.3, 0.9, 0.8, 1
        padding: dp(10)
        size_hint_y: 1
    BoxLayout:
        size_hint_y: None
        height: dp(50)
        spacing: dp(8)
        TextInput:
            id: command
            hint_text: "Nhập lựa chọn / dữ liệu..."
            multiline: False
            size_hint_x: 1
            background_color: 0.08, 0.10, 0.18, 1
            foreground_color: 1, 1, 1, 1
            hint_text_color: 0.5, 0.56, 0.68, 1
            on_text_validate: root.submit()
        Button:
            text: "GỬI"
            size_hint_x: None
            width: dp(82)
            background_normal: ""
            background_color: 0.36, 0.25, 0.85, 1
            on_release: root.submit()
    BoxLayout:
        size_hint_y: None
        height: dp(42)
        spacing: dp(8)
        Button:
            text: "XÓA LOG"
            background_normal: ""
            background_color: 0.12, 0.16, 0.25, 1
            on_release: root.clear_log()
        Button:
            text: "DỪNG HIỂN THỊ"
            background_normal: ""
            background_color: 0.55, 0.16, 0.25, 1
            on_release: root.send_stop()
"""

class QueueWriter:
    def write(self, value):
        if value:
            output_queue.put(str(value))
        return len(value or "")
    def flush(self): pass
    def isatty(self): return True

class NovaRoot(BoxLayout):
    log_text = StringProperty("")
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        Clock.schedule_interval(self.drain_output, 0.12)
    def drain_output(self, _dt):
        chunks = []
        while True:
            try: chunks.append(output_queue.get_nowait())
            except queue.Empty: break
        if chunks:
            cleaned = ANSI_RE.sub("", "".join(chunks))
            # Rich uses terminal markup and control characters; retain readable text.
            cleaned = cleaned.replace("\r", "")
            self.log_text = (self.log_text + cleaned)[-45000:]
            self.ids.terminal.cursor = (0, len(self.ids.terminal.text.splitlines()) - 1)
    def submit(self):
        value = self.ids.command.text
        self.ids.command.text = ""
        input_queue.put(value)
        output_queue.put("\n› " + value + "\n")
    def clear_log(self):
        self.log_text = ""
    def send_stop(self):
        input_queue.put("q")
        output_queue.put("\n[APP] Đã gửi lệnh dừng/quay lại. Nếu tác vụ đang chạy nền, chờ vòng xử lý hiện tại.\n")

def gui_input(prompt=""):
    if prompt:
        output_queue.put(str(prompt))
    return input_queue.get()

builtins.input = gui_input
sys.stdout = QueueWriter()
sys.stderr = QueueWriter()

class TSTNovaApp(App):
    def build(self):
        self.title = "TST-TOOL NOVA"
        Builder.load_string(KV)
        self.root_widget = NovaRoot()
        Clock.schedule_once(lambda _dt: self.start_core(), 0.5)
        return self.root_widget

    def start_core(self):
        def worker():
            try:
                # Keep all runtime data inside Android's private app storage.
                os.makedirs(self.user_data_dir, exist_ok=True)
                os.chdir(self.user_data_dir)
                core_dir = os.path.dirname(os.path.abspath(__file__))
                if core_dir not in sys.path:
                    sys.path.insert(0, core_dir)
                import tst_tool_core
                output_queue.put("\n[NOVA] Đang khởi động TST-TOOL...\n")
                tst_tool_core.main_vth()
                output_queue.put("\n[NOVA] TST-TOOL đã kết thúc.\n")
            except Exception:
                output_queue.put("\n[LỖI KHỞI ĐỘNG]\n" + traceback.format_exc() + "\n")
        threading.Thread(target=worker, daemon=True, name="tst-core").start()

if __name__ == "__main__":
    TSTNovaApp().run()
